//
//  requestGrantSceneClass.swift
//  zaima
//
//  Created by Noushin Gauhar on 2/12/19.
//  Copyright © 2019 Noushin Gauhar. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage

class requestGrantSceneClass: UIViewController,UITableViewDelegate, UITableViewDataSource {
    var name = ["one","two","three"]

    @IBOutlet weak var tableView: UITableView!
    
    var storageref: StorageReference?
    
       var flag = 0
       var j : Int = 0
       var temp: [Book] = []
       
       
       var ref:DatabaseReference!
    
    var ref2:DatabaseReference!
         var booklist = [Book]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        ref2 = Database.database().reference().child("requests").child("Zaima");
       ref = Database.database().reference().child("uploadedBooks").child("Zaima");
              
              ref.observe(DataEventType.value, with: {(snapshot) in
                  if snapshot.childrenCount>0 {
                      self.booklist.removeAll()
                      
                      for books in snapshot.children.allObjects as![DataSnapshot]{
                          let bookObject = books.value as? [String: AnyObject]
                          let bname = bookObject?["book"] as? String ?? ""
                          let bauthor = bookObject?["author"] as? String ?? ""
                          let bprice = bookObject?["price"] as? String ?? ""
                          let book = Book(cover: "", name: bname, author: bauthor, genre: [""], summary: bprice, publish_date: "", language: "Zaima", rating: 0.0)
                          
                          self.booklist.append(book)
                        print(self.booklist.count)
                        
                          
                          
                      }
                    print(self.booklist.count)
                      self.tableView.reloadData()
                  }
                  
              })
             

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 170
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("yui")
        return booklist.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       // print(name[indexPath.row])
        let cell = tableView.dequeueReusableCell(withIdentifier: "reqcell") as! requestCellClassTableViewCell
        
        let  book: Book
               book = booklist[indexPath.row]
        cell.labul2.text = book.name
        cell.author.text = book.author
        cell.price.text = "Price : $" + book.summary
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reqcell") as! requestCellClassTableViewCell
        
                
        
        
        ref2?.child(booklist[indexPath.row].name).child("granted").setValue("yes")
            
    }

}


