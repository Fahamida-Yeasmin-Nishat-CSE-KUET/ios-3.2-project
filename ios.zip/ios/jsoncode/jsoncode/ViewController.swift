//
//  ViewController.swift
//  jsoncode
//
//  Created by Noushin Gauhar on 3/12/19.
//  Copyright © 2019 Projapoti Roy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    final let url = URL(string: "http://www.json-generator.com/api/json/get/bPJbXVlEFu?indent=2");
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

