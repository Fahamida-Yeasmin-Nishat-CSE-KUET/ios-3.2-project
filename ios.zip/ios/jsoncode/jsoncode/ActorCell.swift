//
//  ActorCell.swift
//  jsoncode
//
//  Created by Noushin Gauhar on 3/12/19.
//  Copyright © 2019 Projapoti Roy. All rights reserved.
//

import UIKit

class ActorCell: UITableViewCell {

    @IBOutlet weak var namelbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
