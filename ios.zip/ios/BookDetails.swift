//
//  BookDetails.swift
//  zaima
//
//  Created by Noushin Gauhar on 26/10/19.
//  Copyright © 2019 Noushin Gauhar. All rights reserved.
//

import UIKit
import Firebase
extension UIImageView {
func applyshadowWithCorner(containerView : UIView, cornerRadious : CGFloat){
    containerView.clipsToBounds = false
    containerView.layer.shadowColor = UIColor.black.cgColor
    containerView.layer.shadowOpacity = 1
    containerView.layer.shadowOffset = CGSize.zero
    containerView.layer.shadowRadius = 10
    containerView.layer.cornerRadius = cornerRadious
    containerView.layer.shadowPath = UIBezierPath(roundedRect: containerView.bounds, cornerRadius: cornerRadious).cgPath
    self.clipsToBounds = true
    self.layer.cornerRadius = cornerRadious
}
}

class BookDetails: UIViewController {
    var ref:DatabaseReference?
    var rev: String = ""
    @IBAction func enterb(_ sender: Any) {
        let ref = Database.database().reference().child("add review")
       // let rev = reviewtf.text!
        //ref?.child("add review").child("user").child("review").setValue(rev)
        ref.setValue(["user": self.reviewtf.text!])
    }
    @IBOutlet weak var reviewtf: UITextField!
    @IBOutlet weak var textView: UITextView!
    
    var booklist: [Book] = []
    
    @IBAction func button(_ sender: UIButton) {
    }
    @IBOutlet weak var cover2: UIImageView!
    @IBOutlet weak var cover: UIImageView!
    @IBOutlet weak var cover3: UIImageView!
    lazy var scrollView: UIScrollView = {
        
        let view = UIScrollView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.contentSize.height = 7000
        
        return view
        
        
        
    }()
    
    var recommend : String = ""

   @IBOutlet weak var name: UILabel!
      
      @IBOutlet weak var author: UILabel!
      
      @IBOutlet weak var genre: UILabel!
      
      @IBOutlet weak var summary: UILabel!
      
      @IBOutlet weak var language: UILabel!
      
      @IBOutlet weak var date: UILabel!
      
    @IBOutlet weak var maincover: UIImageView!
    
    
    @IBOutlet weak var backcover: UIImageView!
      @IBOutlet weak var imageHolder: UIView!
      @IBOutlet weak var rating: UILabel!
      
      @IBOutlet weak var cover1: UIImageView!
    
    @IBOutlet weak var star1: UIImageView!
    @IBOutlet weak var star2: UIImageView!
    @IBOutlet weak var star3: UIImageView!
    @IBOutlet weak var star4: UIImageView!
    @IBOutlet weak var star5: UIImageView!
    @IBOutlet weak var uiview: UIView!
    var selectedBook = Book()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(selectedBook.author)
        recommend = selectedBook.genre[0]
    
        view.addSubview(scrollView)
        setupScrollView()
        summary.text = selectedBook.summary
        name.text = selectedBook.name
        author.text = selectedBook.author
        date.text = "Publish Date : "+selectedBook.publish_date
        genre.text = "Genre : "+selectedBook.genre[0]
        language.text = "Language : "+selectedBook.language
        var rat = selectedBook.rating
        if(rat == 1)
        {
            star5.image = UIImage(named: "starfill")
            star1.image = UIImage(named: "star")
            star2.image = UIImage(named: "star")
            star3.image = UIImage(named: "star")
            star4.image = UIImage(named: "star")
        }
        if(rat == 2)
        {
            star5.image = UIImage(named: "starfill")
            star1.image = UIImage(named: "starfill")
            star2.image = UIImage(named: "star")
            star3.image = UIImage(named: "star")
            star4.image = UIImage(named: "star")
        }
        if(rat == 3)
        {
            star5.image = UIImage(named: "starfill")
            star1.image = UIImage(named: "starfill")
            star2.image = UIImage(named: "starfill")
            star3.image = UIImage(named: "star")
            star4.image = UIImage(named: "star")
        }
        if(rat == 4)
        {
            star5.image = UIImage(named: "starfill")
            star1.image = UIImage(named: "starfill")
            star2.image = UIImage(named: "starfill")
            star3.image = UIImage(named: "starfill")
            star4.image = UIImage(named: "star")
            
        }
        if(rat == 5)
        {
            star5.image = UIImage(named: "starfill")
            star1.image = UIImage(named: "starfill")
            star2.image = UIImage(named: "starfill")
            star3.image = UIImage(named: "starfill")
            star4.image = UIImage(named: "starfill")
        }
        
        
        
        
        
        /*language.text = selectedBook.language
        date.text = selectedBook.publish_date
        rating.text = String(selectedBook.rating)
        
        var temp: String
        temp = ""
        for i in 0...selectedBook.genre.count - 1
        {
            temp = temp + selectedBook.genre[i]
            if(i != selectedBook.genre.count - 1){
                temp = temp + " "
            }
        }
        genre.text = temp*/
        
        func blurImage(image:UIImage) -> UIImage? {
            let context = CIContext(options: nil)
            let inputImage = CIImage(image: image)
            let originalOrientation = image.imageOrientation
            let originalScale = image.scale

            let filter = CIFilter(name: "CIGaussianBlur")
            filter?.setValue(inputImage, forKey: kCIInputImageKey)
            filter?.setValue(40.0, forKey: kCIInputRadiusKey)
            
            let outputImage = filter?.outputImage

            var cgImage:CGImage?

            if let asd = outputImage
            {
                cgImage = context.createCGImage(asd, from: (inputImage?.extent)!)
            }

            if let cgImageA = cgImage
            {
                return UIImage(cgImage: cgImageA, scale: originalScale, orientation: originalOrientation)
            }

            return nil
        }
        
        if let imageurl = URL(string: selectedBook.cover){
            do {
                let data = try Data(contentsOf: imageurl)
                maincover.image = UIImage(data: data)
                
                backcover.image = blurImage(image: maincover.image!)
                backcover.layer.opacity = 1.4

            }catch let err{
                print("Error : \(err.localizedDescription)")
            }
        }
        
        var c: Int
        c = 0
        
        for i in 0...booklist.count - 1
        {
            if(recommend == booklist[i].genre[0])
                
            {
                if(booklist[i].name != selectedBook.name){
                c = c+1
                if(c == 1)
                {  if let imageurl = URL(string: booklist[i].cover){
                    do {
                        let data = try Data(contentsOf: imageurl)
                        cover1.image = UIImage(data: data)
                    }catch let err{
                        print("Error : \(err.localizedDescription)")
                    }
                }
                    }
                else if(c == 2)
                {         if let imageurl = URL(string: booklist[i].cover){
                    do {
                        let data = try Data(contentsOf: imageurl)
                        cover2.image = UIImage(data: data)
                    }catch let err{
                        print("Error : \(err.localizedDescription)")
                    }
                }
                }
                else if(c == 3)
                {         if let imageurl = URL(string: booklist[i].cover){
                    do {
                        let data = try Data(contentsOf: imageurl)
                        cover3.image = UIImage(data: data)
                    }catch let err{
                        print("Error : \(err.localizedDescription)")
                    }
                }
                }
                if(c == 3){break}
                }
                
            }
                
        }
        
        maincover.applyshadowWithCorner(containerView: imageHolder, cornerRadious: 5)
        
        
        
        
        // Do any additional setup after loading the view.
    }
    
    func setupScrollView()
    {
        scrollView.topAnchor.constraint(equalTo : view.topAnchor).isActive = true
        scrollView.bottomAnchor.constraint(equalTo : view.bottomAnchor).isActive = true
        scrollView.leftAnchor.constraint(equalTo : view.leftAnchor).isActive = true
        scrollView.rightAnchor.constraint(equalTo : view.rightAnchor).isActive = true
        scrollView.addSubview(uiview)
        
        
    }
    
    
    
    
    //@IBAction func addPost(_sender: Any)
    //{
        //ref?.child("Posts").childByAutoId().setvalue("hello firebase")
        
       //  presentingViewController?.dismiss(animated: true, completion: nil)
    //}
    
    
    
    

}
