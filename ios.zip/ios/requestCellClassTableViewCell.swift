//
//  requestCellClassTableViewCell.swift
//  zaima
//
//  Created by Noushin Gauhar on 2/12/19.
//  Copyright © 2019 Noushin Gauhar. All rights reserved.
//

import UIKit

class requestCellClassTableViewCell: UITableViewCell {


    @IBOutlet weak var `switch`: UISegmentedControl!
    
 
    @IBOutlet weak var labul2: UILabel!
    
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var author: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
