//
//  TableViewCell.swift
//  zaima
//
//  Created by Noushin Gauhar on 2/12/19.
//  Copyright © 2019 Noushin Gauhar. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var bookname: UILabel!
    @IBOutlet weak var author: UILabel!
   
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var user: UILabel!
    @IBOutlet weak var cover: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
