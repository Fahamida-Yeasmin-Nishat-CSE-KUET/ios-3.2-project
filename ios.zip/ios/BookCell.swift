//
//  BookCell.swift
//  zaima
//
//  Created by Noushin Gauhar on 24/10/19.
//  Copyright © 2019 Noushin Gauhar. All rights reserved.
//

import UIKit

class BookCell: UITableViewCell {

    @IBOutlet weak var cover: UIImageView!
    @IBOutlet weak var title: UILabel!
    
    @IBOutlet weak var Author: UILabel!

    @IBOutlet weak var Genre: UILabel!
    
    func setBook(book: Book)
    {
        print("In setbook")
        title.text = book.name
        Author.text = book.author
        var temp: String
        temp = ""
        for i in 0...book.genre.count - 1
        {
            temp = temp + book.genre[i]
            if(i != book.genre.count - 1){
                temp = temp + " "
            }
        }
        Genre.text = temp
        if let imageurl = URL(string: book.cover){
            do {
                let data = try Data(contentsOf: imageurl)
                cover.image = UIImage(data: data)
            }catch let err{
                print("Error : \(err.localizedDescription)")
            }
        }
        
    }
    

}


