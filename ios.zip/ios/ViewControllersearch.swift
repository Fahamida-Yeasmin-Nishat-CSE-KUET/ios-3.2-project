//
//  ViewControllersearch.swift
//  zaima
//
//  Created by Noushin Gauhar on 2/12/19.
//  Copyright © 2019 Noushin Gauhar. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage

class ViewControllersearch: UIViewController {
    var sea : String = ""
    var seaa : String = ""
    var seap : String = ""
    var seal : String = ""
    
    var ref:DatabaseReference?

    @IBAction func yes(_ sender: Any) {
        let key = ref?.childByAutoId().key
        let book = ["book":sea,"author":seaa,"username":seal,"price":seap]
        ref?.child(key!).setValue(book)
        
    }
    @IBOutlet weak var lab: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        lab.text = "Dear "+seal+", Do You Want To Confirm Buying The Book "+sea+"?"
        // Do any additional setup after loading the view.
        
        ref = Database.database().reference().child("requests").child("Zaima")
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    

}
