//
//  ChecklistViewController.swift
//  zaima
//
//  Created by Noushin Gauhar on 30/11/19.
//  Copyright © 2019 Noushin Gauhar. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage


class Search: UIViewController ,UITableViewDataSource,UITableViewDelegate{
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var input: UITextField!
    var storageref: StorageReference?
 
    var flag = 0
    var j : Int = 0
    var temp: [Book] = []
    
    
    var ref:DatabaseReference!
      var booklist = [Book]()
      
    @IBAction func butsearch(_ sender: Any) {
        let txt = input.text ?? ""
      
    
    for i in 0...booklist.count-1{
            
        let str1 = booklist[i].name
            let str = str1.lowercased()
            if str.contains(txt) {
               // print("\(Text) in \(str)")
                flag = 1
                let singlebook = Book(cover: booklist[i].cover, name: booklist[i].name, author: booklist[i].author, genre: booklist[i].genre, summary: booklist[i].summary, publish_date: booklist[i].publish_date, language: booklist[i].language, rating: booklist[i].rating)
                 self.temp.append(singlebook)
                
                   // print(self.temp[j].name)
                    j = j+1
                
                }
        }
        
        var n : Int = booklist.count - 1
              for i in 0...n{
                      //print(i)
                      let index : Int = 0
                     booklist.remove(at: index)
                  n = n - 1
                  }
              
              j=0
              if flag == 1{
              for i in 0...temp.count-1{
                             
               let singlebook = Book(cover: temp[i].cover, name: temp[i].name, author: temp[i].author, genre: temp[i].genre, summary: temp[i].summary, publish_date: temp[i].publish_date, language: temp[i].language, rating: temp[i].rating)
              self.booklist.append(singlebook)
              print(self.booklist[j].name)
              j = j+1
                }
                DispatchQueue.main.async {
                print(self.booklist.count)
                self.tableView.reloadData()
                }
              }
        
    }
    
    
    
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ref = Database.database().reference().child("uploadedBooks").child("Zaima");
        
        ref.observe(DataEventType.value, with: {(snapshot) in
            if snapshot.childrenCount>0 {
                self.booklist.removeAll()
                
                for books in snapshot.children.allObjects as![DataSnapshot]{
                    let bookObject = books.value as? [String: AnyObject]
                    let bname = bookObject?["book"] as? String ?? ""
                    let bauthor = bookObject?["author"] as? String ?? ""
                    let bprice = bookObject?["price"] as? String ?? ""
                    let book = Book(cover: "", name: bname, author: bauthor, genre: [""], summary: bprice, publish_date: "", language: "Zaima", rating: 0.0)
                    
                    self.booklist.append(book)
                    
                    
                }
                self.tableView.reloadData()
            }
            
        })

    }
    
    
    
    
    
    
    
    func  tableView(_ tableView: UITableView, numberOfRowsInSection:Int) -> Int {
        return booklist.count
        }
     func tableView(_ tableView: UITableView, cellForRowAt indexPath:IndexPath) -> UITableViewCell{
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChecklistItem", for: indexPath) as! TableViewCell
        let  book: Book
        book = booklist[indexPath.row]
        storageref = Storage.storage().reference()
        let storageProfileRef = storageref?.child(book.name)
        
        storageProfileRef?.getData(maxSize: 1*1000*1000, completion: {(data,error) in
            if error == nil {
                print(data)
                cell.cover.image = UIImage(data: data!)
            }
            else {
                print("Error fetching cover")
            }
            
            })
        
        
            
        cell.bookname.text = book.name
        cell.author.text = book.author
        cell.user.text = book.language
        cell.price.text = "$"+book.summary
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "search1") as? ViewControllersearch
        let book : Book
         book = booklist[indexPath.row]
        vc?.sea = book.name
        vc?.seaa = book.author
        vc?.seap = book.summary
        vc?.seal = book.language
        
        
        self.present(vc!, animated: true, completion: nil)
    }
    
        
    
}

