//
//  uploadbook.swift
//  zaima
//
//  Created by Noushin Gauhar on 28/11/19.
//  Copyright © 2019 Noushin Gauhar. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage


extension UIView {

    func dropShadow() {
        self.layer.masksToBounds = false
        self.layer.shadowColor = UIColor.gray.cgColor
        self.layer.shadowOpacity = 1
        self.layer.shadowOffset = CGSize.zero
        self.layer.shadowRadius = 5
        self.layer.shadowPath = UIBezierPath(rect: self.bounds).cgPath
        self.layer.shouldRasterize = true
        self.layer.rasterizationScale = UIScreen.main.scale
        self.layer.shadowPath = UIBezierPath(roundedRect: self.bounds, cornerRadius: 5).cgPath
        self.layer.cornerRadius = 5

    }
}

extension UIImageView {

    func dropShadow1() {
        self.layer.masksToBounds = false
        self.layer.shadowColor = UIColor.gray.cgColor
        self.layer.shadowOpacity = 1
        self.layer.shadowOffset = CGSize.zero
        self.layer.shadowRadius = 5
        self.layer.shadowPath = UIBezierPath(rect: self.bounds).cgPath
        self.layer.shouldRasterize = true
        self.layer.rasterizationScale = UIScreen.main.scale
        self.layer.shadowPath = UIBezierPath(roundedRect: self.bounds, cornerRadius: 5).cgPath
        self.layer.cornerRadius = 5

    }
}


class uploadbook: UIViewController {
    
    var ref:DatabaseReference?
    var storageref: StorageReference?
    
    

    @IBOutlet weak var cover: UIImageView!
    
   
    
    @IBOutlet weak var bookpic: UIImageView!
    @IBOutlet weak var pickerbtn: UIButton!
    @IBOutlet weak var uploadbtn: UIButton!
    @IBOutlet weak var view3: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var rating: UITextField!
    @IBOutlet weak var date: UITextField!
    @IBOutlet weak var language: UITextField!
    @IBOutlet weak var summary: UITextView!
    @IBOutlet weak var genre: UITextField!
    @IBOutlet weak var author: UITextField!
    @IBOutlet weak var book: UITextField!
    @IBOutlet weak var uiview: UIView!
    
    @IBOutlet weak var price: UITextField!
    
    var bookt: String = ""
    var authort: String = ""
    var genret: String = ""
    var summaryt: String = ""
    var datet: String = ""
    var ratingt: String = ""
    var languaget: String = ""
    var pricet: String = ""
    
    
    
    lazy var scrollView: UIScrollView = {
        
        let view = UIScrollView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.contentSize.height = 915
        return view
        
        
        
    }()
    
    var imagePicker = UIImagePickerController()
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(scrollView)
        setupScrollView()
        
        
        view1.dropShadow()
        view2.dropShadow()
        view3.dropShadow()
        book.layer.zPosition = 1;
        uploadbtn.layer.zPosition = 1;
        bookpic.layer.zPosition = 1;
        uploadbtn.layer.backgroundColor = UIColor.white.cgColor
        uploadbtn.layer.masksToBounds = false
        uploadbtn.layer.shadowColor = UIColor.gray.cgColor
        uploadbtn.layer.shadowOpacity = 1
        uploadbtn.layer.shadowOffset = CGSize.zero
        summary.layer.borderColor = UIColor.gray.cgColor
        summary.layer.borderWidth = 0.5
        pickerbtn.layer.backgroundColor = UIColor.white.cgColor
        pickerbtn.layer.borderWidth = 0.5
        pickerbtn.layer.cornerRadius = 3
        pickerbtn.layer.masksToBounds = false
        pickerbtn.layer.shadowColor = UIColor.gray.cgColor
        pickerbtn.layer.shadowOpacity = 1
        pickerbtn.layer.shadowOffset = CGSize.zero
    
        imagePicker.delegate = self
        
        ref = Database.database().reference().child("uploadedBooks").child("Zaima")
        storageref = Storage.storage().reference()
        

        // Do any additional setup after loading the view.
    }
    
    @IBAction func pickcover(_ sender: Any) {
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = true
        present(imagePicker, animated: true, completion: nil)
        
    }
   
    @IBAction func uploader2(_ sender: Any) {
        let bookt = book.text!
        let authort = author.text!
        summaryt = summary.text
        let ratingt = book.text!
        let datet = date.text!
        let genret = genre.text!
        let languaget = language.text!
        let pricet = price.text!
        
        guard let coverphoto = cover.image else {
            print("Cover Photo is Required")
            return
            
        }
        
        guard let imageData = coverphoto.jpegData(compressionQuality: 0.4) else {
            return
        }
        let storageProfileRef = storageref?.child(bookt)
        storageProfileRef?.putData(imageData, metadata: nil, completion: { (metadata,error) in
            if error != nil {
                print(error)
                return
            }
            print(metadata)
            
        })
        
        
        
        if(bookt.isEmpty || authort.isEmpty || ratingt.isEmpty || datet.isEmpty || languaget.isEmpty || genret.isEmpty || pricet.isEmpty)
        {
            print("All fields are required");
        }
        else{
        print(bookt)
        
            let key = ref?.childByAutoId().key
            let book = ["book":bookt,"author":authort,"genre":genret,"summary":summaryt,"rating":ratingt,"language":languaget,"price":pricet,"date":datet]
            ref?.child(key!).setValue(book)
            
            
            /*ref?.child("uploadedBooks").child("Zaima").child("book").setValue(bookt)
            ref?.child("uploadedBooks").child("Zaima").child("author").setValue(authort)
        ref?.child("uploadedBooks").child("Zaima").child("genre").setValue(genret)
        ref?.child("uploadedBooks").child("Zaima").child("summary").setValue(summaryt)
        ref?.child("uploadedBooks").child("Zaima").child("language").setValue(languaget)
        ref?.child("uploadedBooks").child("Zaima").child("rating").setValue(ratingt)
        ref?.child("uploadedBooks").child("Zaima").child("date").setValue(datet)
        ref?.child("uploadedBooks").child("Zaima").child("price").setValue(pricet)
        //ref?.child("author").childByAutoId().setValue(["book":authort])*/
            
            let vc = storyboard?.instantiateViewController(withIdentifier: "userprofile") as? ProfileViewController
          
            self.navigationController?.pushViewController(vc!, animated: true)
         
        }
    }
    
    @IBAction func uploader(_ sender: Any) {
        
    }
    func setupScrollView()
    {
        scrollView.topAnchor.constraint(equalTo : view.topAnchor).isActive = true
        scrollView.bottomAnchor.constraint(equalTo : view.bottomAnchor).isActive = true
        scrollView.leftAnchor.constraint(equalTo : view.leftAnchor).isActive = true
        scrollView.rightAnchor.constraint(equalTo : view.rightAnchor).isActive = true
        scrollView.addSubview(uiview)
        
        
    }
    
    

}

extension uploadbook: UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.originalImage] as? UIImage{
            cover.image = image
        }
        dismiss(animated: true, completion: nil)
    }
    
}
