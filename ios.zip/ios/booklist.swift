//
//  booklist.swift
//  zaima
//
//  Created by Noushin Gauhar on 24/10/19.
//  Copyright © 2019 Noushin Gauhar. All rights reserved.
//

import UIKit

struct whole: Decodable {
    let books: [booktmp]
}
struct booktmp: Decodable{
    let name: String
    let author: String
    let genre: [String]
    let cover: String
    let summary: String
    let publish_date: String
    let language: String
    let rating: Float
}
class booklist: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    var bookli: [Book] = []
    
    var temp: [Book] = []
    
    var type: String = ""
    
    var mText: String = ""
    var flag:Int = 0
   
    @IBOutlet weak var seg: UISegmentedControl!
    
    
    @IBOutlet weak var txtFld: UITextField!
    
    
    @IBAction func searchButton(_ sender: UIButton) {
        
        flag = 0
        if type.elementsEqual("")
        {
            type = "author"
        }
    
        if type.elementsEqual("title")
       {
        let Text = txtFld.text ?? ""
        
        var j : Int = 0
        
        for i in 0...bookli.count-1{
            
        let str1 = bookli[i].name
            let str = str1.lowercased()
            if str.contains(Text) {
               // print("\(Text) in \(str)")
                flag = 1
                let singlebook = Book(cover: bookli[i].cover, name: bookli[i].name, author: bookli[i].author, genre: bookli[i].genre, summary: bookli[i].summary, publish_date: bookli[i].publish_date, language: bookli[i].language, rating: bookli[i].rating)
                    self.temp.append(singlebook)
                   // print(self.temp[j].name)
                    j = j+1
                
                }
        }
       // print(bookli.count)
       var n : Int = bookli.count - 1
        for i in 0...n{
                //print(i)
                let index : Int = 0
               bookli.remove(at: index)
            n = n - 1
            }
        
        j=0
        if flag == 1{
        for i in 0...temp.count-1{
                       
         let singlebook = Book(cover: temp[i].cover, name: temp[i].name, author: temp[i].author, genre: temp[i].genre, summary: temp[i].summary, publish_date: temp[i].publish_date, language: temp[i].language, rating: temp[i].rating)
        self.bookli.append(singlebook)
        print(self.bookli[j].name)
        j = j+1
        }
        }
        DispatchQueue.main.async {
        print(self.bookli.count)
        self.tableView.reloadData()
        }
                       
    
        }
    
    
    else if type.elementsEqual("genre")
       {
       let Text = txtFld.text ?? ""
        
        var j : Int = 0
        
        for i in 0...bookli.count-1{
            
        let str1 = bookli[i].genre[0]
            let str = str1.lowercased()
            print(str)
            if str.contains(Text) {
            print("\(Text) in \(str)")
                flag = 1
                let singlebook = Book(cover: bookli[i].cover, name: bookli[i].name, author: bookli[i].author, genre: bookli[i].genre, summary: bookli[i].summary, publish_date: bookli[i].publish_date, language: bookli[i].language, rating: bookli[i].rating)
                    self.temp.append(singlebook)
                   print(self.temp[j].name)
                    j = j+1
                
                }
        }
       // print(bookli.count)
       var n : Int = bookli.count - 1
        for i in 0...n{
                //print(i)
                let index : Int = 0
               // print(i)
          //  print(bookli[0].name)
          //  print("P")
                bookli.remove(at: index)
                //print(bookli[i].name)
               // print(bookli.count)
            n = n - 1
            }
        
        j=0
        if flag  == 1{
        for i in 0...temp.count-1{
                       
         let singlebook = Book(cover: temp[i].cover, name: temp[i].name, author: temp[i].author, genre: temp[i].genre, summary: temp[i].summary, publish_date: temp[i].publish_date, language: temp[i].language, rating: temp[i].rating)
        self.bookli.append(singlebook)
        print(self.bookli[j].name)
        j = j+1
        }
        }
        DispatchQueue.main.async {
        print(self.bookli.count)
        self.tableView.reloadData()
        }
                       
    
        }
        else if type.elementsEqual("author")
             {
             let Text = txtFld.text ?? ""
              
              var j : Int = 0
              
              for i in 0...bookli.count-1{
                  
              let str1 = bookli[i].author
                let str = str1.lowercased()
                  print(str)
                  if str.contains(Text) {
                  print("\(Text) in \(str)")
                      flag = 1
                      let singlebook = Book(cover: bookli[i].cover, name: bookli[i].name, author: bookli[i].author, genre: bookli[i].genre, summary: bookli[i].summary, publish_date: bookli[i].publish_date, language: bookli[i].language, rating: bookli[i].rating)
                          self.temp.append(singlebook)
                         print(self.temp[j].name)
                          j = j+1
                      
                      }
              }
             // print(bookli.count)
             var n : Int = bookli.count - 1
              for i in 0...n{
                      let index : Int = 0
                      bookli.remove(at: index)
                  n = n - 1
                  }
              
              j=0
        if flag == 1{
              for i in 0...temp.count-1{
                             
               let singlebook = Book(cover: temp[i].cover, name: temp[i].name, author: temp[i].author, genre: temp[i].genre, summary: temp[i].summary, publish_date: temp[i].publish_date, language: temp[i].language, rating: temp[i].rating)
              self.bookli.append(singlebook)
              print(self.bookli[j].name)
              j = j+1
              }
                }
              DispatchQueue.main.async {
              print(self.bookli.count)
              self.tableView.reloadData()
              }
                             
          
              }
}
   @IBAction func valueChanged(_ sender: UISegmentedControl) {
    
        if seg.selectedSegmentIndex == 0
        {
            type = "author"
            print(type)
        }
        if seg.selectedSegmentIndex == 1
        {
            type = "genre"
            print(type)
        }
        if seg.selectedSegmentIndex == 2
        {
            type = "title"
            print(type)
        }
    
    }
    
   
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let tempBooks: [booktmp] = []
        tableView.delegate = self
        tableView.dataSource = self
        
        let jsonUrlString = "https://api.myjson.com/bins/ilhhg"
        guard let urlbook = URL(string: jsonUrlString) else { return }
        
        URLSession.shared.dataTask(with: urlbook) { (data,response,err) in
            guard let data = data else {return}
            do{
                let bookList = try JSONDecoder().decode(whole.self, from: data)
                print(bookList.books[0].name)
                
                
                let tempBooks = bookList.books
                
                for i in 0...tempBooks.count - 1 {
                    let singlebook = Book(cover: tempBooks[i].cover, name: tempBooks[i].name, author: tempBooks[i].author, genre: tempBooks[i].genre, summary: tempBooks[i].summary, publish_date: tempBooks[i].publish_date, language: tempBooks[i].language, rating: tempBooks[i].rating)
                    
                    self.bookli.append(singlebook)
                    print(self.bookli[i].name)
                }
                
                DispatchQueue.main.async {
                    print(self.bookli.count)
                    self.tableView.reloadData()
                }
                
                
                        
                
                
            }catch let jsonErr {
                print("Error Serializing json : ",jsonErr)
            }
        }.resume()
        
        /**/
        
     
    }
    
    
    

    
    
    
    

    
    
    
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bookli.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let book = bookli[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "bookCell") as! BookCell
        
        cell.setBook(book: book)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 170
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "BookDetails") as? BookDetails
        print(bookli[indexPath.row])
        
        vc?.selectedBook = bookli[indexPath.row]
        print(vc?.selectedBook)
        vc?.booklist = bookli
        self.present(vc!, animated: true, completion: nil)
    }
    
    
    
    
    
}


