//
//  ProfileViewController.swift
//  zaima
//
//  Created by Noushin Gauhar on 1/12/19.
//  Copyright © 2019 Noushin Gauhar. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage

class ProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    //variables
    var imagePicker = UIImagePickerController()
    let storageRef = Storage.storage().reference()
    let databaseRef = Database.database().reference()
    var finalName : String = ""
    //outlets
    @IBOutlet weak var profile_image: UIImageView!
    @IBOutlet weak var usernameLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       imagePicker.delegate = self
        if Auth.auth().currentUser?.uid == nil {
            logout()
        }
        
        //setupProfile()
        usernameLabel.text = finalName
    }
    
    //actions
    @IBAction func uploadImageButton(_ sender: Any) {
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = true
        present(imagePicker, animated: true, completion: nil)
        
        guard let coverphoto = profile_image.image else {
            print("Cover Photo is Required")
            return
            
        }
        
        guard let imageData = coverphoto.jpegData(compressionQuality: 0.4) else {
            return
        }
        let storageProfileRef = storageRef.child(finalName)
        storageProfileRef.putData(imageData, metadata: nil, completion: { (metadata,error) in
            if error != nil {
                print(error)
                print("meow")
                return
            }
            print(metadata)
            
        }) 
        
        
        
       /* let picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = true
        picker.sourceType = UIImagePickerController.SourceType.photoLibrary
        self.present(picker, animated: true, completion: nil) */
        
    }
    
    //@IBAction func saveChanges(_ sender: Any) {
        //saveChanges()
   // }
    @IBAction func logoutButton(_ sender: Any) {
        logout()
    }
    
    
    //func
    
   /* func setupProfile(){
        let uid = Auth.auth().currentUser?.uid
        
            profile_image.layer.cornerRadius = profile_image.frame.size.width/2
            profile_image.clipsToBounds = true
            
            databaseRef.child("users").child(uid!).observeSingleEvent(of: .value, with: { (DataSnapshot) in
                if let dict = DataSnapshot.value as? [String: AnyObject]{
                    self.usernameLabel.text = dict["username"] as? String
                    if let profileImageURL = dict["pic"] as? String
                    {
                        let url = URL(string: profileImageURL)
                        URLSession.shared.dataTask(with: url!, completionHandler: { (data, response, Error) in
                            if Error != nil{
                                print("Error detected")
                                return
                            }
                            DispatchQueue.main.async {
                                self.profile_image?.image = UIImage(data: data!)
                            }
                            }).resume()
                    }
                }
            })
            
        
    } */
    
    func logout(){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let loginViewController = storyboard.instantiateViewController(identifier: "Login")
        present(loginViewController, animated: true, completion: nil)
    }
    
    
    
   /* func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        var selectedImageFromPicker: UIImage?
        
        if let editedImage = info[.editedImage] as? UIImage{
            selectedImageFromPicker = editedImage
        }else if let originalImage = info[.originalImage] as? UIImage{
            selectedImageFromPicker = originalImage
        }
        if let selectedImage = selectedImageFromPicker{
            profile_image.image = selectedImage
        }
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func saveChanges(){
        let imageName = NSUUID().uuidString
        let storedImage = storageRef.child("profile_images").child(imageName)
        
        if let image = UIImage(named: "example.png") {
            if let data = image.pngData() {
                //let filename = getDocumentsDirectory().appendingPathComponent("copy.png")
                //try? data.write(to: filename)
            }
        }
    } */
 
}
extension ProfileViewController
{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.originalImage] as? UIImage{
            profile_image.image = image
        }
        dismiss(animated: true, completion: nil)
    }
    
}
