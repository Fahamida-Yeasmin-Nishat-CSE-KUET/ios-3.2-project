//
//  demoViewController.swift
//  zaima
//
//  Created by Noushin Gauhar on 2/12/19.
//  Copyright © 2019 Noushin Gauhar. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage

class demoViewController: UIViewController {

    @IBOutlet weak var see: UITextField!
    
    @IBOutlet weak var book: UITextField!
    
    @IBOutlet weak var user: UITextField!
    
    @IBOutlet weak var review: UITextField!
    
    @IBOutlet weak var rating: UITextField!
    
    @IBOutlet weak var use1: UILabel!
    @IBOutlet weak var rev1: UILabel!
    var ref : DatabaseReference?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       // ref = Database.database().reference()

        // Do any additional setup after loading the view.
        ref = Database.database().reference().child("Posts").child("booksreview")
    }
    
    @IBAction func searchrev(_ sender: Any) {
        let aa = see.text
      
        ref?.observe(DataEventType.value, with: {(snapshot) in
            if snapshot.childrenCount>0 {
                for checkuser in
                    snapshot.children.allObjects as! [DataSnapshot]{
                        let userObject = checkuser.value as? [String: AnyObject]
                        let checkBook = userObject?["book"] as? String ?? ""
                        let checkRev = userObject?["review"] as? String ?? ""
                        let checkUser = userObject?["user"] as? String ?? ""
                        
                        if aa == checkBook {
                            self.use1.text = checkUser
                            self.rev1.text = checkRev
                        }
                }
            }
            
        } )
        
    }
    
    @IBAction func addpost(_ sender: Any) {
        let rx = book.text
        let ry = user.text
        let rz = review.text
        //let ro = rating.text
     //   let bb = rating.text
       // print(rx)
       // print(ry)
       // print(rz)
       // print(ro)
      //  print(bb)
        //ref?.child("Posts").childByAutoId().child("bookname").setValue(rx)
        //ref?.child("Posts").childByAutoId().child("username").setValue(ry)
        
        let key = ref?.childByAutoId().key
        let x = ["book":rx,"user":ry,"review":rz]
        ref?.child(key!).setValue(x)

    }
    
    
    
    
  /*  @IBAction func enterb(_ sender: Any) {
       // let rr = demo.text
      // print(rr)
        ref = Database.database().reference().child("add review").child("bookname")*/
    
        
        
        
        
        
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


