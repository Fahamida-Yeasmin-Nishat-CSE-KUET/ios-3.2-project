//
//  SignupViewController.swift
//  zaima
//
//  Created by Noushin Gauhar on 1/12/19.
//  Copyright © 2019 Noushin Gauhar. All rights reserved.
//

import UIKit
import Firebase



class SignupViewController: UIViewController {
    
    //variables
    let databaseRef = Database.database().reference(fromURL: "https://iosproject-dd375.firebaseio.com/")
    var curUser : String = ""
    //outlets
    
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    //action

    @IBAction func signupButton(_ sender: Any) {
        signup()
        
        
    }

     @IBAction func loginButton(_ sender: Any) {
        login()
     }
    
    //func
    
    func login(){
        guard let username = username.text else{
            print("username issue")
            return
        }
        guard let email = email.text else{
            print("email issue")
            return
        }
        guard let password = password.text else{
            print("password issue")
            return
        }
        
        let ref = databaseRef.child("users")
        ref.observe(DataEventType.value, with:
            {(snapshot) in
                if snapshot.childrenCount>0 {
                    for checkuser in
                        snapshot.children.allObjects as![DataSnapshot]{
                            let userObject = checkuser.value as? [String: AnyObject]
                            let checkUsername = userObject?["username"] as? String ?? ""
                            let checkemail = userObject?["email"] as? String ?? ""
                            let checkpassword = userObject?["password"] as? String ?? ""
                            
                            if checkUsername == username {
                                self.curUser = username
                                self.performSegue(withIdentifier: "username", sender: self)
                            }
                            
                            
                    }
                }
        })
        
       /* Auth.auth().signIn(withEmail: email, password:  password, completion: {(user, error) in
            if error != nil {
                print(error!)
                return
            }
            self.dismiss(animated: true, completion: nil)
        }) */
    }
    
    func signup(){
        guard let username = username.text else{
                   print("username issue")
                    
                   return
               }
               guard let email = email.text else{
                   print("email issue")
                   return
               }
               guard let password = password.text else{
                   print("password issue")
                   return
               }
              
        //curUser = username
       
        
        let userReference = self.databaseRef.child("users")
                let values = ["username": username, "email": email, "password": password]
                
                let key = userReference.childByAutoId().key
                userReference.child(key!).setValue(values)
                   
                   userReference.onDisconnectUpdateChildValues(values
                       , withCompletionBlock: {(error, ref) in
                           if error != nil {
                               print(error!)
                               return
                           }
                           self.dismiss(animated: true, completion: nil)
                   })
        
                   
               }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        var vc = segue.destination as! ProfileViewController
        vc.finalName = self.curUser
    }
    }


