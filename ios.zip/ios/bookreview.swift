//
//  bookreview.swift
//  zaima
//
//  Created by Noushin Gauhar on 3/12/19.
//  Copyright © 2019 Noushin Gauhar. All rights reserved.
//

import Foundation


class bookreview{
    
    var book: String?
    var user: String?
    var review: String?
    var rating: String?
    
    init(book:String?, name:String?, review:String?, rating:String?)
    {
        self.book = book;
        //self.user = user;
        self.review = review;
        self.rating = rating;
        
    }
    
}
