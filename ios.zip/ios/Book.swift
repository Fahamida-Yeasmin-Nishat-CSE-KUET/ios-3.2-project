//
//  Book.swift
//  zaima
//
//  Created by Noushin Gauhar on 24/10/19.
//  Copyright © 2019 Noushin Gauhar. All rights reserved.
//

import Foundation
import UIKit
class Book
{
    var name: String
    var author: String
    var genre: [String]
    var cover: String
    var summary: String
    var publish_date: String
    var language: String
    var rating: Float
    
    init() {
       
        self.name = ""
        self.author = ""
        self.genre = []
        self.cover = ""
        self.language = ""
        self.publish_date = ""
        self.rating = 0.0
        self.summary = ""
        
    }
    
    init(cover: String,name:String,author:String,genre:[String],summary: String,publish_date: String, language: String,rating:Float) {
       
        self.name = name
        self.author = author
        self.genre = genre
        self.cover = cover
        self.language = language
        self.publish_date = publish_date
        self.rating = rating
        self.summary = summary
        
    }
    
  
}
